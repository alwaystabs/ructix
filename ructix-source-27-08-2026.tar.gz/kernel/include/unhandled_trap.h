#ifndef UNHANDLED_TRAP_H
#define UNHANDLED_TRAP_H

#include <stdint.h>
#include "uart.h"
#include "panic.h"
#include "kstring.h"
void unhandled_trap_c(uint64_t cause, uint64_t epc);

#endif